<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ResiduosSolido extends Model
{
    protected $table = 'residuossolidos';
    protected $fillable = ['nombre'];
}
