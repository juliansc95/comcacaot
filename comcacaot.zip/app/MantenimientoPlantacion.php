<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MantenimientoPlantacion extends Model
{
    protected $table = 'mantenimientoplantacions';
    protected $fillable = ['nombre']; 
}
