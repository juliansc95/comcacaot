<div class="sidebar">
            <nav class="sidebar-nav">
                <ul class="nav">
                    <li class="nav-title">
                        Supervisor Ventas
                    </li>
                    <li class="nav-item nav-dropdown">
                        <a class="nav-link nav-dropdown-toggle" href="#"><i class="icon-basket"></i> Ventas</a>
                        <ul class="nav-dropdown-items">
                            <li @click="menu=8" class="nav-item">
                                <a class="nav-link" href="#"><i class="icon-basket-loaded"></i> Ventas</a>
                            </li>
                            <li  @click="menu=9" class="nav-item">
                                <a class="nav-link" href="#"><i class="icon-notebook"></i> Tipos cacao</a>
                            </li>
                            <li  @click="menu=10" class="nav-item">
                                <a class="nav-link" href="#"><i class="icon-notebook"></i> Puntos de Compra y/o beneficio</a>
                            </li>
                        </ul>
                    </li>
                   
                    
            </nav>
            <button class="sidebar-minimizer brand-minimizer" type="button"></button>
        </div>